import mongoose from 'mongoose';
const orderSchema = mongoose.Schema({
    LspId: {  
        type: mongoose.Schema.Types.ObjectId,
        ref: "Lsp",
     },
    name: {
        type: String,
        required: true,
        enum: ["T-shirt", "pant", "shirt", "jeans", "kurta", "saree", "salwar", "kurti", "suit", "blazer", "coat", "jacket", "sweater", "hoodie", "jumpsuit", "shorts", "skirt", "leggings", "trousers", "shoes", "sandals", "flip-flops", "boots", "sneakers", "slippers", "loafers", "heels", "wedges", "flats", "slippers", "flip-flops", "sandals", "shoes", "handbags", "wallets", "belts"],

    },
    category: {
        type: String,
        enum: ["Men's Clothing", "Women's Clothing", "Household Items"],
        required: true,
    },
    quantity: {
        type: Number,
        required: "Quantity is required!"
    },
    deliveryAddress: {
        type: mongoose.Schema.Types.ObjectId,
        required: "delivery address required"
    },
    paymentMethod: {
        type: mongoose.Schema.Types.ObjectId,
        required: "Payment method is required!"
    },
    expectedDeliveryDate: {
        type: Date,
        required: "Expected delivery date is required!"
    },
    status: {
        type: String,
        enum: ["pending", "processing", "completed", "cancelled"],
    }
});

const orderListSchema = mongoose.Schema({
    _id: {
        type: mongoose.Schema.Types.ObjectId, ref: "User"
    },
    orderList: [orderSchema]
}, { timestamps: true });

const Order = mongoose.model('Order', orderListSchema);

export default Order;
